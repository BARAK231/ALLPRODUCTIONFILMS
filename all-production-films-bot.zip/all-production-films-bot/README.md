# ALL PRODUCTION FILMS Bot

Telegram Bot + FastAPI + PostgreSQL foundation.

## Current features
- User registration
- Per-user private channel invite link
- 50-referral unlock for publishing films
- Referral join tracking from channel invite links
- Film storage using Telegram file_id
- Text film search
- Leaderboard
- Configurable source-channel table
- Webhook deployment suitable for Render

## Important
The bot must be an administrator of `@afghanproduction` with permission to invite users via links. Set `ADMIN_IDS` to your Telegram numeric ID.

## Render
Create a PostgreSQL database, then a Web Service. Build command:
`pip install -r requirements.txt`
Start command:
`uvicorn app.main:app --host 0.0.0.0 --port $PORT`

Set all variables from `.env.example`.

## Next development
- Full Mini App search API and UI
- Poster/image matching with perceptual hashes
- Admin panel
- Add/remove source channels from the bot
- Film metadata wizard after upload
- Pagination and categories
- Duplicate detection

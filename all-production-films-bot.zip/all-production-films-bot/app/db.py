import asyncpg
from .config import settings

pool: asyncpg.Pool | None = None

SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (
 id BIGINT PRIMARY KEY,
 username TEXT,
 first_name TEXT,
 joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 referral_owner BIGINT REFERENCES users(id),
 referral_count INT NOT NULL DEFAULT 0,
 upload_unlocked BOOLEAN NOT NULL DEFAULT FALSE,
 referral_invite_link TEXT,
 referral_invite_name TEXT UNIQUE
);
CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS source_channels (
 id SERIAL PRIMARY KEY,
 title TEXT NOT NULL,
 username_or_id TEXT NOT NULL UNIQUE,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 sort_order INT NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS films (
 id BIGSERIAL PRIMARY KEY,
 title TEXT NOT NULL,
 file_id TEXT NOT NULL,
 file_type TEXT NOT NULL,
 file_name TEXT,
 poster_file_id TEXT,
 year TEXT,
 quality TEXT,
 genre TEXT,
 added_by BIGINT REFERENCES users(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS films_title_idx ON films USING gin (to_tsvector('simple', title));
CREATE TABLE IF NOT EXISTS referral_joins (
 id BIGSERIAL PRIMARY KEY,
 inviter_id BIGINT NOT NULL REFERENCES users(id),
 joined_user_id BIGINT NOT NULL UNIQUE REFERENCES users(id),
 invite_link TEXT NOT NULL,
 joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
'''

async def init_db():
    global pool
    pool = await asyncpg.create_pool(settings.database_url, min_size=1, max_size=5)
    async with pool.acquire() as con:
        await con.execute(SCHEMA)
        await con.execute("INSERT INTO source_channels(title, username_or_id, sort_order) VALUES($1,$2,$3) ON CONFLICT DO NOTHING", "اصلي چینل", settings.main_channel, 1)

async def get_user(user_id: int):
    async with pool.acquire() as con:
        return await con.fetchrow("SELECT * FROM users WHERE id=$1", user_id)

async def upsert_user(tg_user, referral_owner: int | None = None):
    async with pool.acquire() as con:
        row = await con.fetchrow("SELECT * FROM users WHERE id=$1", tg_user.id)
        if row:
            await con.execute("UPDATE users SET username=$2, first_name=$3 WHERE id=$1", tg_user.id, tg_user.username, tg_user.first_name)
            return await con.fetchrow("SELECT * FROM users WHERE id=$1", tg_user.id)
        if referral_owner == tg_user.id:
            referral_owner = None
        await con.execute("INSERT INTO users(id,username,first_name,referral_owner) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING", tg_user.id, tg_user.username, tg_user.first_name, referral_owner)
        return await con.fetchrow("SELECT * FROM users WHERE id=$1", tg_user.id)

async def set_referral_link(user_id: int, link: str, name: str):
    async with pool.acquire() as con:
        await con.execute("UPDATE users SET referral_invite_link=$2, referral_invite_name=$3 WHERE id=$1", user_id, link, name)

async def register_join(inviter_id: int, joined_user_id: int, invite_link: str):
    if inviter_id == joined_user_id:
        return False
    async with pool.acquire() as con:
        async with con.transaction():
            exists = await con.fetchval("SELECT 1 FROM referral_joins WHERE joined_user_id=$1", joined_user_id)
            if exists:
                return False
            await con.execute("INSERT INTO referral_joins(inviter_id,joined_user_id,invite_link) VALUES($1,$2,$3)", inviter_id, joined_user_id, invite_link)
            await con.execute("UPDATE users SET referral_count=referral_count+1, upload_unlocked=(referral_count+1 >= $2) WHERE id=$1", inviter_id, settings.referral_target)
            return True

async def search_films(q: str, limit=30):
    async with pool.acquire() as con:
        return await con.fetch("SELECT * FROM films WHERE title ILIKE $1 ORDER BY created_at DESC LIMIT $2", f"%{q}%", limit)

async def add_film(title, file_id, file_type, file_name, added_by, poster_file_id=None, year=None, quality=None, genre=None):
    async with pool.acquire() as con:
        return await con.fetchrow("INSERT INTO films(title,file_id,file_type,file_name,poster_file_id,year,quality,genre,added_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *", title,file_id,file_type,file_name,poster_file_id,year,quality,genre,added_by)

async def all_channels():
    async with pool.acquire() as con:
        return await con.fetch("SELECT * FROM source_channels WHERE active=TRUE ORDER BY sort_order,id")

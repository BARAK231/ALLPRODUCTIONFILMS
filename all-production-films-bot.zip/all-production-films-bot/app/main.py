import secrets
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, Update, ChatMemberUpdated, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart
from aiogram.enums import ChatMemberStatus
from .config import settings
from .db import init_db, pool, upsert_user, get_user, set_referral_link, register_join, search_films, add_film, all_channels

bot = Bot(settings.bot_token)
dp = Dispatcher()

async def ensure_referral_link(user_id: int) -> str:
    row = await get_user(user_id)
    if row and row['referral_invite_link']:
        return row['referral_invite_link']
    name = f"ref_{user_id}_{secrets.token_hex(3)}"
    link = await bot.create_chat_invite_link(chat_id=settings.main_channel, name=name)
    await set_referral_link(user_id, link.invite_link, name)
    return link.invite_link

async def channel_ok(user_id: int) -> bool:
    try:
        m = await bot.get_chat_member(settings.main_channel, user_id)
        return m.status in {ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}
    except Exception:
        return False

@dp.my_chat_member()
async def bot_added(event: ChatMemberUpdated):
    pass

@dp.chat_member()
async def joined(event: ChatMemberUpdated):
    if event.chat.username and event.chat.username.lower() == settings.main_channel.lstrip('@').lower():
        link = event.invite_link.invite_link if event.invite_link else None
        if link:
            async with pool.acquire() as con:
                inviter = await con.fetchval("SELECT id FROM users WHERE referral_invite_link=$1", link)
            if inviter:
                await register_join(inviter, event.from_user.id, link)

@dp.message(CommandStart())
async def start(message: Message):
    ref_owner = None
    parts = (message.text or '').split(maxsplit=1)
    if len(parts) == 2 and parts[1].startswith('ref_') and parts[1][4:].isdigit():
        ref_owner = int(parts[1][4:])
    await upsert_user(message.from_user, ref_owner)
    link = await ensure_referral_link(message.from_user.id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='🔎 فلم ولټوه', callback_data='search')],
        [InlineKeyboardButton(text='🎬 فلمونه نشر کړه', callback_data='publish')],
        [InlineKeyboardButton(text='👥 زما ریفرل', callback_data='referral')],
        [InlineKeyboardButton(text='🏆 ریفرل لیډران', callback_data='leaders')],
        [InlineKeyboardButton(text='📢 پښتو ترجمه فلمونه', callback_data='channels')],
        [InlineKeyboardButton(text='🌐 Mini App', web_app=WebAppInfo(url=settings.app_url))],
    ])
    await message.answer('🎬 ALL PRODUCTION FILMS\n\nفلم ولټوه، د فلمونو معلومات وګوره، او د نشرولو لپاره خپل Referral بشپړ کړه.\n\n🔒 د فلم نشرولو شرط: 50 کسان زموږ اصلي چینل ته راوستل.', reply_markup=kb)

@dp.message(F.video | F.document)
async def receive_film(message: Message):
    row = await get_user(message.from_user.id)
    if not row or not row['upload_unlocked']:
        link = await ensure_referral_link(message.from_user.id)
        count = row['referral_count'] if row else 0
        await message.answer(f'🔒 د فلم نشرولو اجازه لا نه ده فعاله.\n\n👥 ریفرل: {count}/{settings.referral_target}\n\nخپل ځانګړی لینک له ملګرو سره شریک کړه:\n{link}')
        return
    file_id = message.video.file_id if message.video else message.document.file_id
    file_type = 'video' if message.video else 'document'
    default_title = (message.caption or '').strip() or (message.video.file_name if message.video else message.document.file_name) or 'بې نومه فلم'
    await add_film(default_title, file_id, file_type, message.video.file_name if message.video else message.document.file_name, message.from_user.id)
    await message.answer(f'✅ فلم ثبت شو!\n\n🎬 {default_title}\n\nاوس ټول کاروونکي یې د Search له لارې موندلی شي.')

@dp.message(F.text)
async def text_search(message: Message):
    if (message.text or '').startswith('/'):
        return
    rows = await search_films(message.text.strip())
    if not rows:
        await message.answer('🔎 فلم پیدا نه شو. د فلم نوم بیا ولیکه.')
        return
    for r in rows[:10]:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='🎬 فلم ترلاسه کړه', callback_data=f"film:{r['id']}")]])
        await message.answer(f"🎬 {r['title']}\n📅 {r['year'] or '-'}\n⚙️ {r['quality'] or '-'}\n🎭 {r['genre'] or '-'}", reply_markup=kb)

@dp.callback_query(F.data == 'search')
async def cb_search(c):
    await c.message.answer('🔎 د فلم نوم ولیکه؛ زه به یې درته ولټوم.')
    await c.answer()

@dp.callback_query(F.data == 'publish')
async def cb_publish(c):
    row = await get_user(c.from_user.id)
    if row and row['upload_unlocked']:
        await c.message.answer('🎬 اجازه فعاله ده. خپل فلم د Video یا Document په توګه همین Bot ته Send/Forward کړه.')
    else:
        link = await ensure_referral_link(c.from_user.id)
        count = row['referral_count'] if row else 0
        await c.message.answer(f'🔒 د فلم نشرولو لپاره {settings.referral_target} کسان پکار دي.\n\n👥 ستا شمېر: {count}/{settings.referral_target}\n\n🔗 ستا ځانګړی لینک:\n{link}\n\nهر نوی کس باید زموږ اصلي چینل ته د همدې لینک له لارې Join شي.')
    await c.answer()

@dp.callback_query(F.data == 'referral')
async def cb_ref(c):
    row = await get_user(c.from_user.id)
    link = await ensure_referral_link(c.from_user.id)
    count = row['referral_count'] if row else 0
    await c.message.answer(f'👥 زما ریفرل\n\n{count}/{settings.referral_target}\n\n🔗 ځانګړی لینک:\n{link}')
    await c.answer()

@dp.callback_query(F.data == 'leaders')
async def cb_leaders(c):
    async with pool.acquire() as con:
        rows = await con.fetch("SELECT first_name, username, referral_count FROM users ORDER BY referral_count DESC LIMIT 10")
    text='🏆 ریفرل لیډران\n\n'
    for i,r in enumerate(rows,1): text += f"{i}. {r['first_name'] or '-'} — {r['referral_count']} 👥\n"
    await c.message.answer(text); await c.answer()

@dp.callback_query(F.data == 'channels')
async def cb_channels(c):
    rows=await all_channels(); text='📢 پښتو ترجمه فلمونه\n\n' + '\n'.join(f"• {r['title']}: {r['username_or_id']}" for r in rows)
    await c.message.answer(text); await c.answer()

@dp.callback_query(F.data.startswith('film:'))
async def cb_film(c):
    fid=int(c.data.split(':')[1])
    async with pool.acquire() as con: r=await con.fetchrow('SELECT * FROM films WHERE id=$1',fid)
    if not r: await c.answer('فلم پیدا نه شو.', show_alert=True); return
    if r['file_type']=='video': await c.message.answer_video(r['file_id'], caption=f"🎬 {r['title']}")
    else: await c.message.answer_document(r['file_id'], caption=f"🎬 {r['title']}")
    await c.answer()

@dp.callback_query(F.data.startswith('admin:'))
async def admin_callbacks(c):
    await c.answer()

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    await bot.set_webhook(f"{settings.app_url}/telegram/webhook/{settings.webhook_secret}", allowed_updates=dp.resolve_used_update_types())
    yield
    await bot.delete_webhook()
    await bot.session.close()

app=FastAPI(title='ALL PRODUCTION FILMS', lifespan=lifespan)

@app.post('/telegram/webhook/{secret}')
async def webhook(secret: str, request: Request):
    if secret != settings.webhook_secret: raise HTTPException(403)
    data=await request.json(); update=Update.model_validate(data, context={'bot':bot})
    await dp.feed_update(bot, update)
    return {'ok':True}

@app.get('/health')
async def health(): return {'ok':True,'service':'ALL PRODUCTION FILMS'}

@app.get('/', response_class=HTMLResponse)
async def root(): return '<h2>ALL PRODUCTION FILMS Bot is running.</h2><p>Open the bot in Telegram.</p>'
